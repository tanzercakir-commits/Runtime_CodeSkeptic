function hot(n){let s=0;for(let i=0;i<n;i++)s=(s+i*7)%1000003;return s}
let r=0; for(let k=0;k<2000;k++) r+=hot(5000);
console.log(r>0?"ok":"no");
