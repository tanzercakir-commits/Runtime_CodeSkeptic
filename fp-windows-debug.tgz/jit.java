public class jit { public static void main(String[] a){ long s=0;
  for(int k=0;k<2000;k++){ for(int i=0;i<5000;i++) s=(s+i*7L)%1000003L; }
  System.out.println(s>0?"ok":"no"); } }
